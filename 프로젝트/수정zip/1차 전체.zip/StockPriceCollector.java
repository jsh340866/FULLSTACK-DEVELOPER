package com.example.demo.domain.service;

import com.example.demo.domain.dto.StockPriceDto;
import com.example.demo.domain.entity.StockPrice;
import com.example.demo.domain.repository.CompanyRepository;
import com.example.demo.domain.repository.StockPriceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class StockPriceCollector {

    private final CompanyRepository companyRepository;
    private final StockPriceRepository stockPriceRepository;
    private final RestTemplate restTemplate;

    @Value("${stock.api.base-url}")
    private String baseUrl;

    @Value("${stock.api.key}")
    private String apiKey;

    // 비동기 실행 - 전체 종목 주가 수집 (백그라운드 처리)
    @Async("stockExecutor")
    public void collect(LocalDate startDate, LocalDate endDate) {

        int savedCount = 0;
        int page = 0;
        final int PAGE_SIZE = 100;

        while (true) {

            // Company 테이블에서 종목코드만 100건씩 페이징 조회
            Pageable pageable = PageRequest.of(page, PAGE_SIZE);
            Page<String> stockCodePage = companyRepository.findAllStockCodes(pageable);
            List<String> stockCodes = stockCodePage.getContent();

            if (stockCodes.isEmpty()) break;

            log.info("페이지 {}: {}건 처리 중", page, stockCodes.size());

            // 병렬 스트림으로 종목별 주가 수집 (처리 속도 향상)
            int pageCount = stockCodes.parallelStream()
                    .mapToInt(stockCode -> {
                        try {
                            return collectByDateRange(stockCode, startDate, endDate);
                        } catch (Exception e) {
                            log.error("종목 전체 실패: {}", stockCode, e);
                            return 0;
                        }
                    })
                    .sum();

            savedCount += pageCount;

            if (!stockCodePage.hasNext()) break;
            page++;
        }

        log.info("전체 저장 완료: {}건", savedCount);
    }

    // 특정 종목의 날짜 범위별 주가 수집
    private int collectByDateRange(String stockCode, LocalDate startDate, LocalDate endDate) {

        int savedCount = 0;

        for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {

            try {

                // 이미 해당 종목 + 날짜 데이터가 있으면 중복 저장 방지
                // srtnCd = stockCode, basDt = date (새 필드명)
                if (stockPriceRepository.findBySrtnCdAndBasDt(stockCode, date).isPresent()) {
                    log.info("이미 존재, 스킵: {} {}", stockCode, date);
                    continue;
                }

                // 공공데이터 API 호출 후 XML 파싱
                String xml = requestApi(stockCode, date);
                StockPriceDto dto = parseXml(xml, stockCode, date);

                if (dto == null) {
                    log.warn("데이터 없음 SKIP: {} {}", stockCode, date);
                    continue;
                }

                // DTO → 새 StockPrice 엔티티로 변환 후 저장
                stockPriceRepository.save(dto.toEntity());
                savedCount++;

                log.info("저장 완료: {} {}", stockCode, date);

            } catch (Exception e) {
                log.error("날짜 수집 실패: {} {}", stockCode, date, e);
            }
        }

        return savedCount;
    }

    // 공공데이터 API 호출 (XML 문자열 반환)
    private String requestApi(String stockCode, LocalDate date) {
        String url = buildUrl(stockCode, date);
        return restTemplate.getForObject(url, String.class);
    }

    // API URL 생성 - 종목코드(likeSrtnCd)와 기준일(basDt) 파라미터 사용
    private String buildUrl(String stockCode, LocalDate date) {
        return UriComponentsBuilder
                .fromHttpUrl(baseUrl)
                .queryParam("serviceKey", apiKey)
                .queryParam("numOfRows", 1)
                .queryParam("pageNo", 1)
                .queryParam("likeSrtnCd", stockCode)
                .queryParam("basDt", date.format(DateTimeFormatter.ofPattern("yyyyMMdd")))
                .build(true)
                .toUriString();
    }

    // XML 파싱 → StockPriceDto 변환
    // 새 StockPrice 엔티티 필드명 기준: srtnCd, basDt, clpr, mkp, fltRt, lstgStCnt, mrktTotAmt
    private StockPriceDto parseXml(String xml, String stockCode, LocalDate date) {

        if (xml == null || xml.isBlank()) return null;

        try {
            // XML에서 필요한 값 추출 (기존 StockPriceXmlParser 로직 인라인 처리)
            String clpr = extractTag(xml, "clpr");           // 종가
            String mkp = extractTag(xml, "mkp");             // 시가
            String fltRt = extractTag(xml, "fltRt");         // 등락률
            String lstgStCnt = extractTag(xml, "lstgStCnt"); // 상장주식수
            String mrktTotAmt = extractTag(xml, "mrktTotAmt"); // 시가총액

            // 종가가 없으면 해당 날짜 거래 없음으로 간주
            if (clpr == null || clpr.isBlank()) return null;

            // 새 StockPriceDto 필드명에 맞게 매핑
            return StockPriceDto.builder()
                    .srtnCd(stockCode)                          // 종목코드
                    .basDt(date)                                // 기준일
                    .clpr(parseLong(clpr))                      // 종가
                    .mkp(parseLong(mkp))                        // 시가
                    .fltRt(parseDouble(fltRt))                  // 등락률
                    .lstgStCnt(parseLong(lstgStCnt))            // 상장주식수 (발행주식수 대체)
                    .mrktTotAmt(parseLong(mrktTotAmt))          // 시가총액
                    .createdAt(LocalDateTime.now())
                    .updatedAt(LocalDateTime.now())
                    .build();

        } catch (Exception e) {
            log.error("XML 파싱 실패: {} {}", stockCode, date, e);
            return null;
        }
    }

    // XML 태그 값 추출 유틸
    private String extractTag(String xml, String tag) {
        String open = "<" + tag + ">";
        String close = "</" + tag + ">";
        int start = xml.indexOf(open);
        int end = xml.indexOf(close);
        if (start == -1 || end == -1) return null;
        return xml.substring(start + open.length(), end).trim();
    }

    // 문자열 → Long 변환 (콤마 제거)
    private Long parseLong(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return Long.parseLong(value.replace(",", "").trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // 문자열 → Double 변환
    private Double parseDouble(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return Double.parseDouble(value.replace(",", "").trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
