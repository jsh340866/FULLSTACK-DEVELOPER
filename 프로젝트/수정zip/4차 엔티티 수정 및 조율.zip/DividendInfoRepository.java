package com.example.demo.domain.repository;

import com.example.demo.domain.entity.DividendInfo;
import com.example.demo.domain.entity.DividendInfoId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

// PK가 복합키(DividendInfoId) - corpCode + dividendKind 조합으로 보통주/우선주 구분 저장
@Repository
public interface DividendInfoRepository extends JpaRepository<DividendInfo, DividendInfoId> {

    // corpCode로 해당 회사 배당 정보 전체 조회 - 보통주/우선주 둘 다 가져올 때 사용
    List<DividendInfo> findByCorpCode(String corpCode);

    // corpCode + dividendKind로 중복 체크 - 동일 데이터 재저장 방지
    boolean existsByCorpCodeAndDividendKind(String corpCode, String dividendKind);
}
