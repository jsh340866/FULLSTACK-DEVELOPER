package com.example.demo.domain.service;

import com.example.demo.domain.entity.Company;
import com.example.demo.domain.repository.CompanyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class DartCompanyDetailCollector {

    private final CompanyRepository companyRepository;
    private final RestTemplate restTemplate;

    @Value("${dart.api.key}")
    private String apiKey;

    private static final int SLEEP_MS = 200; // DART API 호출 간격 - company.json은 개별 호출이라 넉넉하게 설정
    private static final String COMPANY_URL = "https://opendart.fss.or.kr/api/company.json";

    // DB에 저장된 Company 목록에서 corpCode를 꺼내 company.json 호출 후 corpCls 업데이트
    @Transactional
    public void collectCorpCls() {

        // DB에서 전체 Company 조회 - corpCode 기준으로 company.json 호출
        List<Company> companies = companyRepository.findAll();

        int successCount = 0;
        int failCount = 0;

        for (Company company : companies) {

            try {

                // company.json API 호출 - corpCode로 개별 기업 상세 조회
                String url = COMPANY_URL + "?crtfc_key=" + apiKey + "&corp_code=" + company.getCorpCode();
                Map<String, Object> response = restTemplate.getForObject(url, Map.class);

                // 응답 없거나 실패면 스킵
                if (response == null || !"000".equals(response.get("status"))) {
                    log.warn("API 실패: {} {}", company.getCorpName(), response != null ? response.get("status") : "null");
                    failCount++;
                    continue;
                }

                // corp_cls 추출 - Y:코스피, K:코스닥, N:코넥스, E:기타
                String corpCls = (String) response.get("corp_cls");

                if (corpCls == null || corpCls.isBlank()) {
                    log.warn("corpCls 없음: {}", company.getCorpName());
                    failCount++;
                    continue;
                }

                // Company 도메인 메서드로 corpCls 업데이트
                company.updateCorpCls(corpCls);
                successCount++;

                log.info("corpCls 업데이트: {} → {}", company.getCorpName(), corpCls);

                Thread.sleep(SLEEP_MS); // DART API 호출 제한 방지

            } catch (Exception e) {
                log.error("처리 실패: {}", company.getCorpName(), e);
                failCount++;
            }
        }

        // @Transactional + dirty checking으로 자동 update (saveAll 불필요)
        log.info("corpCls 수집 완료 - 성공: {}건, 실패: {}건", successCount, failCount);
    }
}
