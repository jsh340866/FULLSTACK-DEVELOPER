package com.example.demo.domain.controller;

import com.example.demo.domain.service.DartCompanyCollector;
import com.example.demo.domain.service.DartCompanyDetailCollector;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class TestController {

    private final DartCompanyCollector collector;
    private final DartCompanyDetailCollector detailCollector; // corpCls 수집용

    // DART에서 전체 상장 기업 목록 수집 후 Company 테이블에 저장
    @GetMapping("/company/load")
    public String load() {
        collector.collectCompanies();
        return "완료";
    }

    // company.json으로 corpCls(코스피/코스닥) 업데이트
    // /company/load 실행 후 별도로 호출
    @GetMapping("/company/corpCls")
    public String loadCorpCls() {
        detailCollector.collectCorpCls();
        return "완료";
    }
}
